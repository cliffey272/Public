Configuration Main
{

Param ( [string] $nodeName, [string] $newPwd )

Import-DscResource -ModuleName PSDesiredStateConfiguration, cChoco, xStorage, xDSCFirewall, xComputerManagement, xPendingReboot, xNetworking, xSystemSecurity

Node $nodeName
  {
	LocalConfigurationManager 
        {
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }
	
	   Service WindowsFirewall
        {
            Name = "MPSSvc"
            StartupType = "Automatic"
            State = "Running"
        }

        xDSCFirewall Public
        {
            Ensure = "Absent"
            Zone = "Public"
            DependsOn = "[Service]WindowsFirewall"
        }

        xDSCFirewall Private
        {
            Ensure = "Absent"
            Zone = "Private"
            DependsOn = "[Service]WindowsFirewall"
        }
         xDSCFirewall Domain
        {
            Ensure = "Absent"
            Zone = "Domain"
            DependsOn = "[Service]WindowsFirewall"
        }

        xIEEsc EnableIEEscAdmin
        {
            IsEnabled = $False
            UserRole = "Administrators"
        }
                
        xIEEsc EnableIEEscUser
        {
            IsEnabled = $True
            UserRole = "Users"
        }


        File FolderC
            {
                Type = "Directory"
                Ensure = "Present"
                DestinationPath = "C:\filestore"
				
             }

        xWaitforDisk Disk2
			{
				DiskId = 2
				RetryIntervalSec = 60
				RetryCount = 60
			} 


        xDisk EVolume
			{
				DiskId = 2
				DriveLetter = 'F'
				FSLabel = 'Logs'
				FSFormat = 'NTFS'
                DependsOn = "[xWaitforDisk]Disk2" 
			}
		
	    File FolderE
            {
                Type = "Directory"
                Ensure = "Present"
                DestinationPath = "F:\SQLLogs"
				
             }
       
	    xWaitforDisk Disk3
			{
				DiskId = 3
				RetryIntervalSec = 60
				RetryCount = 60
			} 
		
	    xDisk FVolume
			{
				DiskId = 3
				DriveLetter = 'G'
				FSLabel = 'Data'
				FSFormat = 'NTFS'
                DependsOn = "[xWaitforDisk]Disk3"
			}
        File FolderF
            {
                Type = "Directory"
                Ensure = "Present"
                DestinationPath = "G:\SQLData"
				
             }

    	       
	    xWaitforDisk Disk4
			{
				DiskId = 4
				RetryIntervalSec = 60
				RetryCount = 60
			} 
	    xDisk GVolume
			{
				DiskId = 4
				DriveLetter = 'H'
				FSLabel = 'APPS'
				FSFormat = 'NTFS'
                DependsOn = "[xWaitforDisk]Disk4"
			}
		File FolderG
            {
                Type = "Directory"
                Ensure = "Present"
                DestinationPath = "H:\Apps"
				
             }

        xWaitforDisk Disk5
			{
				DiskId = 5
				RetryIntervalSec = 60
				RetryCount = 60
			} 
		xDisk HVolume
			{
				DiskId = 5
				DriveLetter = 'I'
				FSLabel = 'Backups'
				FSFormat = 'NTFS'
                DependsOn = "[xWaitforDisk]Disk5"
			}
		File FolderH
            {
                Type = "Directory"
                Ensure = "Present"
                DestinationPath = "I:\Backups"
				
             }    
                   


        $IISFeatures = "Web-WebServer","Web-Common-Http","Web-Default-Doc","Web-Dir-Browsing","Web-Http-Errors","Web-Static-Content","Web-Http-Redirect","Web-DAV-Publishing","Web-Health","Web-Http-Logging","Web-Custom-Logging","Web-Log-Libraries","Web-ODBC-Logging","Web-Request-Monitor","Web-Http-Tracing","Web-Performance","Web-Stat-Compression","Web-Dyn-Compression","Web-Security","Web-Filtering","Web-Basic-Auth","Web-CertProvider","Web-Client-Auth","Web-Digest-Auth","Web-Cert-Auth","Web-IP-Security","Web-URL-Auth","Web-Windows-Auth","Web-App-Dev","Web-Net-Ext","Web-Net-Ext45","Web-AppInit","Web-ASP","Web-Asp-Net","Web-Asp-Net45","Web-CGI","Web-ISAPI-Ext","Web-ISAPI-Filter","Web-Includes","Web-WebSockets","Web-Mgmt-Tools","Web-Mgmt-Console","Web-Mgmt-Compat","Web-Metabase","Web-Lgcy-Mgmt-Console","Web-Lgcy-Scripting","Web-WMI","Web-Scripting-Tools","Web-Mgmt-Service"
        Install-WindowsFeature -Name $IISFeatures
        
        Enable-WindowsOptionalFeature -Online -FeatureName "WCF-HTTP-Activation45" -All
        Enable-WindowsOptionalFeature -Online -FeatureName "WCF-HTTP-Activation" -All


        
        $filename = (Get-Date).ToString("yyyyMMddhhmmss")
        $filename = -join ("c:\temp\", $filename, ".log")
        md "c:\temp\"


        $VMname = hostname | Out-File $filename
        $ScriptDIR = "C:\Packages\Plugins\Microsoft.Powershell.DSC\2.83.0.0\DSCWork\TMSBuildDSC.0" | Out-File $filename -Append
        $SQLScript = -join($ScriptDIR, "\AmendSQL.ps1") | Out-File $filename -Append
        $FilePathWithQuotes = '"{0}"' -f $SQLScript | Out-File $filename -Append

        #$username = -join($VMname,'\','a365admin') | Out-File $filename -Append
        $username = "asc-prod\a365admin"
        $argument = -join("-NoProfile -WindowStyle Hidden -file ",$FilePathWithQuotes) 

        $action = New-ScheduledTaskAction -Execute 'Powershell.exe' -Argument "-NoProfile -WindowStyle Hidden -file C:\Packages\Plugins\Microsoft.Powershell.DSC\2.83.0.0\DSCWork\TMSBuildDSC.0\AmendSQL.ps1" | Out-File $filename -Append
        
        $trigger =  New-ScheduledTaskTrigger -Once -At 9AM | Out-File $filename -Append
        
        Register-ScheduledTask -Action $action -Trigger $trigger -TaskName "ChangeSQL" -Description "Change SQL Logon Method" -User "asc-prod\a365admin" -Password "LoCAwxvqmcSfJd0!" | Out-File $filename -Append
        
        
        Start-ScheduledTask -TaskName "ChangeSQL" | Out-File $filename -Append



        #import-module SqlPS -DisableNameChecking | Out-File $filename

        #copy "C:\Packages\Plugins\Microsoft.Powershell.DSC\2.83.0.0\DSCWork\TMSBuildDSC.0\xSQLModule\sqlserver.21.0.17199.nupkg" "C:\Temp\psModule\sqlserver.21.0.17199.nupkg"  | Out-File $filename

        #$ScriptDIR = pwd
        #$PSModule = "C:\Packages\Plugins\Microsoft.Powershell.DSC\2.83.0.0\DSCWork\TMSBuildDSC.0\xSQLModule" | Out-File $filename
        #$FilePathWithQuotes = '"{0}"' -f $PSModule | Out-File $filename -Append

        #Register-PSRepository -Name 'SQLPS' -SourceLocation "C:\Program Files (x86)\Microsoft SQL Server\130\Tools\PowerShell\Modules" | Out-File $filename -Append


        #Install-Module -Name SQLPS -AllowClobber -Repository 'SQLPS' -Confirm:$False -Force | Out-File $filename -Append
        #Install-Module -Name SqlServer -AllowClobber -Confirm:$False -Force | Out-File $filename -Append
        #Import-Module  "C:\Program Files (x86)\Microsoft SQL Server\130\Tools\PowerShell\Modules\SQLPS" -DisableNameChecking | Out-File $filename -Append


        # Loads the SQL Server Management Objects (SMO)  

        #$ErrorActionPreference = "Stop"
          
        #$sqlpsreg="HKLM:\SOFTWARE\Microsoft\PowerShell\1\ShellIds\Microsoft.SqlServer.Management.PowerShell.sqlps130" | Out-File $filename
        #$sqlpsPath="C:\Program Files (x86)\Microsoft SQL Server\130\Tools\Binn"
        #if (Get-ChildItem $sqlpsreg -ErrorAction "SilentlyContinue")
        #{  
        #    throw "SQL Server Provider for Windows PowerShell is not installed."   | Out-File $filename -Append
        #}  
        #else
        #{  
        #    $item = Get-ItemProperty $sqlpsreg   | Out-File $filename -Append
        #    $sqlpsPath = [System.IO.Path]::GetDirectoryName($item.Path)   | Out-File $filename -Append
        #}  
          
       #$assemblylist =
       #"Microsoft.SqlServer.Management.Common",  
       #"Microsoft.SqlServer.Smo",  
       #"Microsoft.SqlServer.Dmf ",  
       #"Microsoft.SqlServer.Instapi ",  
       #"Microsoft.SqlServer.SqlWmiManagement ",  
       #"Microsoft.SqlServer.ConnectionInfo ",  
       #"Microsoft.SqlServer.SmoExtended ",  
       #"Microsoft.SqlServer.SqlTDiagM ",  
       #"Microsoft.SqlServer.SString ",  
       #"Microsoft.SqlServer.Management.RegisteredServers ",  
       #"Microsoft.SqlServer.Management.Sdk.Sfc ",  
       #"Microsoft.SqlServer.SqlEnum ",  
       #"Microsoft.SqlServer.RegSvrEnum ",  
       #"Microsoft.SqlServer.WmiEnum ",  
       #"Microsoft.SqlServer.ServiceBrokerEnum ",  
       #"Microsoft.SqlServer.ConnectionInfoExtended ",  
       #"Microsoft.SqlServer.Management.Collector ",  
       #"Microsoft.SqlServer.Management.CollectorEnum",  
       #"Microsoft.SqlServer.Management.Dac",  
       #"Microsoft.SqlServer.Management.DacEnum",  
       #"Microsoft.SqlServer.Management.Utility"   | Out-File $filename -Append
       #  
       #foreach ($asm in $assemblylist)  
       #{  
       #    $asm = [Reflection.Assembly]::LoadWithPartialName($asm)   | Out-File $filename -Append
       #}  
       #  
       #Push-Location   | Out-File $filename -Append
       #cd "C:\Program Files (x86)\Microsoft SQL Server\130\Tools\PowerShell\Modules\SQLPS"
       ##cd $sqlpsPath  
       #update-FormatData -prependpath SQLProvider.Format.ps1xml | Out-File $filename -Append
       #Pop-Location   | Out-File $filename -Append
       #
       #
       #
       #
       #[string]$newPwd = 'C0mp13xP@55word%' | Out-File $filename -Append
       #
       #$SQLserver = hostname | Out-File $filename -Append
       ## Connect to the instance using SMO
       #$s = new-object ('Microsoft.SqlServer.Management.Smo.Server') $SQLserver | Out-File $filename -Append
       #[string]$nm = $s.Name | Out-File $filename -Append
       #[string]$mode = $s.Settings.LoginMode | Out-File $filename -Append
       #write-output "Instance Name: $nm" | Out-File $filename -Append
       #write-output "Login Mode: $mode" | Out-File $filename -Append
       ##Change to Mixed Mode
       #$s.Settings.LoginMode = [Microsoft.SqlServer.Management.SMO.ServerLoginMode]::Mixed | Out-File $filename -Append
       ## Make the changes
       #$s.Alter() | Out-File $filename -Append
       ## Restart the SQL service
       #net stop "MSSQLSERVER" | Out-File $filename -Append
       #net start "MSSQLSERVER" | Out-File $filename -Append
       #
       ## Enable SA and reset password
       ##$query0 = "EXEC xp_instance_regwrite N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'LoginMode', REG_DWORD, 2"
       #$query1 = "ALTER LOGIN sa ENABLE" | Out-File $filename -Append
       #$query2 = "ALTER LOGIN sa WITH PASSWORD = '$newPwd'"  | Out-File $filename -Append
       ##Invoke-Sqlcmd -ServerInstance $SQLserver -Database 'MASTER' -Query $query0
       ##net stop "MSSQLSERVER"
       ##net start "MSSQLSERVER"
       #Invoke-Sqlcmd -ServerInstance $SQLserver -Database 'MASTER' -Query $query1 | Out-File $filename -Append
       #Invoke-Sqlcmd -ServerInstance $SQLserver -Database 'MASTER' -Query $query2 | Out-File $filename -Append






       
 <# This commented section represents an example configuration that can be updated as required.
    WindowsFeature WebManagementConsole
    {
      Name = "Web-Mgmt-Console"
      Ensure = "Present"
    }
    WindowsFeature WebManagementService
    {
      Name = "Web-Mgmt-Service"
      Ensure = "Present"
    }
    WindowsFeature ASPNet45
    {
      Name = "Web-Asp-Net45"
      Ensure = "Present"
    }
    WindowsFeature HTTPRedirection
    {
      Name = "Web-Http-Redirect"
      Ensure = "Present"
    }
    WindowsFeature CustomLogging
    {
      Name = "Web-Custom-Logging"
      Ensure = "Present"
    }
    WindowsFeature LogginTools
    {
      Name = "Web-Log-Libraries"
      Ensure = "Present"
    }
    WindowsFeature RequestMonitor
    {
      Name = "Web-Request-Monitor"
      Ensure = "Present"
    }
    WindowsFeature Tracing
    {
      Name = "Web-Http-Tracing"
      Ensure = "Present"
    }
    WindowsFeature BasicAuthentication
    {
      Name = "Web-Basic-Auth"
      Ensure = "Present"
    }
    WindowsFeature WindowsAuthentication
    {
      Name = "Web-Windows-Auth"
      Ensure = "Present"
    }
    WindowsFeature ApplicationInitialization
    {
      Name = "Web-AppInit"
      Ensure = "Present"
    }
    Script DownloadWebDeploy
    {
        TestScript = {
            Test-Path "C:\WindowsAzure\WebDeploy_amd64_en-US.msi"
        }
        SetScript ={
            $source = "https://download.microsoft.com/download/0/1/D/01DC28EA-638C-4A22-A57B-4CEF97755C6C/WebDeploy_amd64_en-US.msi"
            $dest = "C:\WindowsAzure\WebDeploy_amd64_en-US.msi"
            Invoke-WebRequest $source -OutFile $dest
        }
        GetScript = {@{Result = "DownloadWebDeploy"}}
        DependsOn = "[WindowsFeature]WebServerRole"
    }
    Package InstallWebDeploy
    {
        Ensure = "Present"  
        Path  = "C:\WindowsAzure\WebDeploy_amd64_en-US.msi"
        Name = "Microsoft Web Deploy 3.6"
        ProductId = "{ED4CC1E5-043E-4157-8452-B5E533FE2BA1}"
        Arguments = "ADDLOCAL=ALL"
        DependsOn = "[Script]DownloadWebDeploy"
    }
    Service StartWebDeploy
    {                    
        Name = "WMSVC"
        StartupType = "Automatic"
        State = "Running"
        DependsOn = "[Package]InstallWebDeploy"
    } #>
  }
}