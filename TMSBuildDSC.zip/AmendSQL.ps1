﻿


        #Enable SQL Mixed mode, enable sa and reset its password

        #Install-Module -Name SqlServer -AllowClobber -Force
        #Import-Module SqlServer -DisableNameChecking -Verbose
        $filename = (Get-Date).ToString("yyyyMMddhhmmss")
        $filename = -join ("c:\temp\", $filename, ".log")
        
        import-module SqlPS -DisableNameChecking | Out-File $filename
        [string]$newPwd = 'C0mp13xP@55word%' | Out-File $filename -Append
        
        $SQLserver = hostname | Out-File $filename -Append
        # Connect to the instance using SMO
        $s = new-object ('Microsoft.SqlServer.Management.Smo.Server') $SQLserver | Out-File $filename -Append
        [string]$nm = $s.Name | Out-File $filename -Append
        [string]$mode = $s.Settings.LoginMode | Out-File $filename -Append
        write-output "Instance Name: $nm" | Out-File $filename -Append
        write-output "Login Mode: $mode" | Out-File $filename -Append
        #Change to Mixed Mode
        $s.Settings.LoginMode = [Microsoft.SqlServer.Management.SMO.ServerLoginMode]::Mixed | Out-File $filename -Append
        # Make the changes
        $s.Alter() | Out-File $filename -Append
        # Restart the SQL service
        net stop "MSSQLSERVER" | Out-File $filename -Append
        net start "MSSQLSERVER" | Out-File $filename -Append

        # Enable SA and reset password
        #$query0 = "EXEC xp_instance_regwrite N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'LoginMode', REG_DWORD, 2"
        $query1 = "ALTER LOGIN sa ENABLE" | Out-File $filename -Append
        $query2 = "ALTER LOGIN sa WITH PASSWORD = '$newPwd'"  | Out-File $filename -Append
        #Invoke-Sqlcmd -ServerInstance $SQLserver -Database 'MASTER' -Query $query0
        #net stop "MSSQLSERVER"
        #net start "MSSQLSERVER"
        Invoke-Sqlcmd -ServerInstance $SQLserver -Database 'MASTER' -Query $query1 | Out-File $filename -Append
        Invoke-Sqlcmd -ServerInstance $SQLserver -Database 'MASTER' -Query $query2 | Out-File $filename -Append


        

        #Unregister-ScheduledTask -TaskName "ChangeSQL" -Confirm:$false
    




        #$VMname = hostname
        #$ScriptDIR = pwd
        #$SQLScript = -join($ScriptDIR, "\AmendSQL.ps1")
        #$FilePathWithQuotes = '"{0}"' -f $SQLScript
        #$username = -join($VMname,'\','a365admin')
        #
        #$action = New-ScheduledTaskAction -Execute 'Powershell.exe' -Argument "-NoProfile -WindowStyle Hidden -file $($FilePathWithQuotes)"
        #
        #$trigger =  New-ScheduledTaskTrigger -Once -At 9AM
        #
        #Register-ScheduledTask -Action $action -Trigger $trigger -TaskName "ChangeSQL" -Description "Change SQL Logon Method" -User $username -Password "LoCAwxvqmcSfJd0!"
        #
        #
        #Start-ScheduledTask -TaskName "ChangeSQL" -





        
        #$ScriptDIR = pwd
        #$PSModule = -join($ScriptDIR, "\xSQLModule\sqlserver.21.0.17199.nupkg")
        #$FilePathWithQuotes = '"{0}"' -f $PSModule
        #
        #
        #
        #
        #Register-PSRepository -Name 'TempSQLRepo' -SourceLocation "C:\Users\andre\Downloads\TMSBuildDSC\xSQLModule"
        #
        #
        #Install-Module -Name SqlServer -Repository 'TempSQLRepo' -AllowClobber -Confirm:$False -Force | Out-File $filename