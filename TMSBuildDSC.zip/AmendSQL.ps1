﻿        Param ( [string] $newPwd )
        #Enable SQL Mixed mode, enable sa and reset its password

        #Import-Module SqlServer -DisableNameChecking -Verbose
        
        import-module SqlPS -DisableNameChecking
        $newPwd = Get-ItemProperty -Path "HKLM:\SYSTEM\ControlSet001\Control\Session Manager\Environment" -Name "SQLPASS" | Select-Object -ExpandProperty SQLPASS
        $SQLserver = hostname
        # Connect to the instance using SMO
        $s = new-object ('Microsoft.SqlServer.Management.Smo.Server') $SQLserver
        [string]$nm = $s.Name
        [string]$mode = $s.Settings.LoginMode
        write-output "Instance Name: $nm"
        write-output "Login Mode: $mode"
        #Change to Mixed Mode
        $s.Settings.LoginMode = [Microsoft.SqlServer.Management.SMO.ServerLoginMode]::Mixed
        # Make the changes
        $s.Alter()
        # Restart the SQL service
        net stop "MSSQLSERVER"
        net start "MSSQLSERVER"

        # Enable SA and reset password
        $query1 = "ALTER LOGIN sa ENABLE"
        $query2 = "ALTER LOGIN sa WITH PASSWORD = '$newPwd'"
        $ChangeDB1Query = "EXEC xp_instance_regwrite N'HKEY_LOCAL_MACHINE' , N'Software\Microsoft\MSSQLServer\MSSQLServer' , N'DefaultData' , REG_SZ , N'G:\SQLData'"
        $ChangeDB2Query = "EXEC xp_instance_regwrite N'HKEY_LOCAL_MACHINE' , N'Software\Microsoft\MSSQLServer\MSSQLServer' , N'DefaultLog' , REG_SZ , N'F:\SQLLogs'"
        $ChangeDB3Query = "EXEC xp_instance_regwrite N'HKEY_LOCAL_MACHINE' , N'Software\Microsoft\MSSQLServer\MSSQLServer' , N'BackupDirectory' , REG_SZ , N'I:\Backup'"
        $ChangeSQLMemory = "DECLARE @maxMem INT = 2048; EXEC sp_configure 'show advanced options', 1 RECONFIGURE; EXEC sp_configure 'max server memory', @maxMem RECONFIGURE; DECLARE @minMem INT = 2048; EXEC sp_configure 'show advanced options', 1 RECONFIGURE; EXEC sp_configure 'min server memory', @minMem RECONFIGURE;"
        $ChangeDBQueryFull = "EXEC xp_instance_regwrite N'HKEY_LOCAL_MACHINE' , N'Software\Microsoft\MSSQLServer\MSSQLServer' , N'DefaultData' , REG_SZ , N'G:\SQLData'; EXEC xp_instance_regwrite N'HKEY_LOCAL_MACHINE' , N'Software\Microsoft\MSSQLServer\MSSQLServer' , N'DefaultLog' , REG_SZ , N'F:\SQLLogs'; EXEC xp_instance_regwrite N'HKEY_LOCAL_MACHINE' , N'Software\Microsoft\MSSQLServer\MSSQLServer' , N'BackupDirectory' , REG_SZ , N'I:\Backup';"
        Invoke-Sqlcmd -ServerInstance $SQLserver -Database 'MASTER' -Query $query1
        Invoke-Sqlcmd -ServerInstance $SQLserver -Database 'MASTER' -Query $query2
        Invoke-Sqlcmd -ServerInstance $SQLserver -Database 'MASTER' -Query $ChangeDBQueryFull
        Invoke-Sqlcmd -ServerInstance $SQLserver -Database 'MASTER' -Query $ChangeSQLMemory

        # Restart the SQL service
        net stop "MSSQLSERVER"
        net start "MSSQLSERVER"

        Get-Item -Path "HKLM:\SYSTEM\ControlSet001\Control\Session Manager\Environment" | Remove-ItemProperty -Name SQLPASS
        
        
        
