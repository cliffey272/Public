﻿        Param ( [string] $newPwd )
        write-host "new password is: " $newPwd
        #Enable SQL Mixed mode, enable sa and reset its password

        #Import-Module SqlServer -DisableNameChecking -Verbose
        
        import-module SqlPS -DisableNameChecking
        $newPwd = Get-ItemProperty -Path "HKLM:\SYSTEM\ControlSet001\Control\Session Manager\Environment" -Name "SQLPASS" | Select-Object -ExpandProperty SQLPASS
        $SQLserver = hostname
        # Connect to the instance using SMO
        $s = new-object ('Microsoft.SqlServer.Management.Smo.Server') $SQLserver
        [string]$nm = $s.Name
        [string]$mode = $s.Settings.LoginMode
        write-output "Instance Name: $nm"
        write-output "Login Mode: $mode"
        #Change to Mixed Mode
        $s.Settings.LoginMode = [Microsoft.SqlServer.Management.SMO.ServerLoginMode]::Mixed
        # Make the changes
        $s.Alter()
        # Restart the SQL service
        net stop "MSSQLSERVER"
        net start "MSSQLSERVER"

        # Enable SA and reset password
        $query1 = "ALTER LOGIN sa ENABLE"
        $query2 = "ALTER LOGIN sa WITH PASSWORD = '$newPwd'"
        Invoke-Sqlcmd -ServerInstance $SQLserver -Database 'MASTER' -Query $query1
        Invoke-Sqlcmd -ServerInstance $SQLserver -Database 'MASTER' -Query $query2

        Get-Item -Path "HKLM:\SYSTEM\ControlSet001\Control\Session Manager\Environment" | Remove-ItemProperty -Name SQLPASS
        
