﻿


        #Enable SQL Mixed mode, enable sa and reset its password

        #Install-Module -Name SqlServer -AllowClobber -Force
        #Import-Module SqlServer -DisableNameChecking -Verbose
        
        
        import-module SqlPS -DisableNameChecking
        [string]$newPwd = 'C0mp13xP@55word%'
        
        $SQLserver = hostname
        # Connect to the instance using SMO
        $s = new-object ('Microsoft.SqlServer.Management.Smo.Server') $SQLserver
        [string]$nm = $s.Name
        [string]$mode = $s.Settings.LoginMode
        write-output "Instance Name: $nm"
        write-output "Login Mode: $mode"
        #Change to Mixed Mode
        $s.Settings.LoginMode = [Microsoft.SqlServer.Management.SMO.ServerLoginMode]::Mixed
        # Make the changes
        $s.Alter()
        # Restart the SQL service
        net stop "MSSQLSERVER"
        net start "MSSQLSERVER"

        # Enable SA and reset password
        #$query0 = "EXEC xp_instance_regwrite N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'LoginMode', REG_DWORD, 2"
        $query1 = "ALTER LOGIN sa ENABLE"
        $query2 = "ALTER LOGIN sa WITH PASSWORD = '$newPwd'" 
        #Invoke-Sqlcmd -ServerInstance $SQLserver -Database 'MASTER' -Query $query0
        #net stop "MSSQLSERVER"
        #net start "MSSQLSERVER"
        Invoke-Sqlcmd -ServerInstance $SQLserver -Database 'MASTER' -Query $query1
        Invoke-Sqlcmd -ServerInstance $SQLserver -Database 'MASTER' -Query $query2


        

        Unregister-ScheduledTask -TaskName "ChangeSQL" -Confirm:$false
    